(function() {
    'use strict';

    angular
        .module('todos', [
            'sofa'
        ])
})();