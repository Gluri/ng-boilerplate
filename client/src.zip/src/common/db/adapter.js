(function() {

    'use strict';

    angular
        .module('adapters', [
            'oc.lazyLoad'
            ])
        
        .factory('adapter', adapter);

        adapter.$inject = [
            '$rootScope', 
            '$injector', 
            '$q', 
            '$ocLazyLoad'
        ];

        function adapter($rootScope, $injector, $q, $ocLazyLoad) {
            var adapters = {};
            var dbs = {};

            var yngutils = $injector.get('yngutils');

            function loadDb(Adapter, adapConf, scope, callback) {
                var dbname = adapConf.dbname;
                if (!dbname[dbname]) {
                    dbs[dbname] = new Adapter(dbname, adapConf.url, yngutils.ASC);
                    var config = {
                        opts: {
                            filter: function(doc) { return true;
    						//	if (doc.type == 'matricola') { return true }
                            //  else return false;
                            }
                            //, //,headers: {'Cookie': 'mycookie'}
                            //withCredentials:true, 
                            //cookieAuth: {username:'admin', password:'pass'}
                        }   //, {withCredentials:true, cookieAuth: {username:'admin', password:'pass'}}
                    };

                    var config2 = {
                        opts: {
                            filter: function(doc) {
                                return false;
                            }
                        }
                    };

                    dbs[dbname].properties({ changes: config, to: config, from: config });
                }


					//  var prov=adapters[a.name].provider();
					//  prov.destroy('crmdata');
					/* prov.destroy(function(err, info) { 
					console.log('Error: ' + err); 
					console.log('Info: ' + info); 
					}); //this is line 38, referenced in errors below
					*/

					scope.loaded = true; // don't show spinner if already bound
					return dbs[dbname].bind(scope).then(function() {
						// Most production environments would not call cleanup() here and would instead call it
						// via a background process like a cron job. We will call cleanup() here as we don't
						// want to rely on an external cron job to cleanup our database when using adapters like
						// DeltaPouchyng.
						if (callback !== undefined) {callback();}
						dbs[dbname].cleanup();
						return dbs[dbname];
					});
            }

            return function(myadapter, scope, dbname, config, callback) {
                // var a = $rootScope.adapter;
                var a = myadapter;
                if (!adapters[a.adapter]) {
                    return $ocLazyLoad.load({ // dynamically load the js files
                        name: 'factoryng',
                        files: a.files
                    }).then(function() {

                        adapters[a.adapter] = $injector.get(a.adapter); // dynamically inject the adapter
                        return loadDb(adapters[a.adapter], a, scope, callback);
                    });

                } else {
                    return loadDb(adapters[a.adapter], a, scope, callback);
                }
            };
        }
})();
