(function() {

    'use strict';

    angular
        .module('crmData', [])
        .service('crmService', crmService);

        crmService.$inject = [
            '$rootScope', 
            'adapters', 
            'adapter'
        ];

        function crmService($rootScope, adapters, adapter) {
            var db = {};
            db.hasLoadForm = false;

            db.resetDb = function() {
                db.destroy(function(err, info) {
                    console.log('Error: ' + err);
                    console.log('Info: ' + info);
                }); //this is line 38, referenced in errors below
                showFillups(); //redraws the UI
            };


            db.loadFormsSchema = function() {
                function callback() {
                    //alert('call back 1');
                   
                }
                var adap = adapter(adapters[0], $rootScope, 'crmforms', {}, callback);
                return adap;
            }

            function _init_getForm(name, scope) {
				

                var docForm = null;
                var len = $rootScope.crmforms.length;
                for (var i = 0; i < len; i++){
                    if (name === $rootScope.crmforms[i].$id) {
                        docForm = $rootScope.crmforms[i].data;
                        break;
                    }
                }
                
                if (docForm!=null){
					var fields_schema=docForm.schema.properties;
					var fields=docForm.form;
					var fieldsGrid=fields_schema;
					var colDef=null;
					
					scope.selectedID=[];
					
					if(docForm.hasOwnProperty('grids'))
						var fieldsGrid=docForm.grids;
					
					scope.gridOptions.columnDefs=[];
					
					for(var ind in fields) {
						var field=fields[ind];
						//if(typeof fieldsGrid[field] == 'undefined') { 
						if(fieldsGrid.hasOwnProperty(field)){
								var prop=fieldsGrid[field];
								var title='';
								if(prop.hasOwnProperty('displayName')) title=prop.displayName;
								else title = prop.title;
								
								scope.gridOptions.columnDefs.push({'name':title,'field':field}); //alert(prop.title); //colDef.push(fields_schema); //doSomethingWith(obj[prop]);
						}
					}
					
					scope.SelectedRows=[];
					scope.gridOptions.selectedItems =scope.SelectedRows;
					
					/*scope.gridOptions.afterSelectionChange= function (rowItem, evt) {      
						//alert(theRow.entity.id);
						 if (rowItem.selected) 
								//scope.selectedIDs = [];
								alert(rowItem);
						//angular.forEach($scope.mySelections, function ( item ) {
							//scope.selectedIDs.push( item )
						//});
					}*/
					
				
					
					scope.gridApi.selection.on.rowSelectionChanged(scope,function(row){
						if (row.isSelected)
							scope.SelectedRows=[row];
							scope.modelData =row.entity;
							$rootScope.homeCtrl.setState(scope,'model');
						//$scope.gridApi.selection.getSelectedRows();
						//console.log(msg);
					});
					
					scope.mySelections=[];
					scope.gridOptions.selectedItems= scope.mySelections;
					
						
				} 
                
                if (!$rootScope.crmforms[0]) {return 0;}

                if (docForm != null) {
                    scope.schema = docForm.schema;
                    scope.form = docForm.form;
                    scope.schemaJson = JSON.stringify(scope.schema, undefined, 2);
                    scope.formJson = JSON.stringify(scope.form, undefined, 2);
                    return true;
                } else {return false;}
            }

            db.getForm = function(name, scope) {
				
                if (db.hasLoadForm === true){
                    _init_getForm(name, scope);
                    
                } else db.loadFormsSchema().then(function(projs) {
                    console.log('forms done binding');
                    projs.cleanup();
                    db.hasLoadForm = true;
                    db.allForms = $rootScope.crmforms[0];

                    _init_getForm(name, scope);
                });
                
                
                
                scope.itParses = true;
				scope.itParsesForm = true;
				scope.$watch('schemaJson',function(val,old){
					if (val && val !== old) {
						try {
							scope.schema = JSON.parse(scope.schemaJson);
							scope.itParses = true;
						} catch (e){
							scope.itParses = false;
						}
					}
				});
		  
		  
				scope.$watch('formJson',function(val,old){
					if (val && val !== old) {
					  try {
						scope.form = JSON.parse(scope.formJson);
						scope.itParsesForm = true;
					  } catch (e){
						scope.itParsesForm = false;
					  }
					}
				});
					
				scope.$watch('selectedTest',function(val){
					if (val) {
					
						scope.schema =val.data.schema;
						scope.form   = val.data.form;
						scope.schemaJson = JSON.stringify(scope.schema,undefined,2);
						scope.formJson   = JSON.stringify(scope.form,undefined,2);
						scope.modelData = val.data.model ||  {}; //[{name:'etto',email:'email',comment:'mio commento'}]

					}
				});
				
				 scope.submitForm = function(form, model) {
						// First we broadcast an event so all fields validate themselves
						scope.$broadcast('schemaFormValidate');
						// Then we check if the form is valid
						
					
						if (form.$valid) {
						//	alert('You did it!');
							scope.edit=false;
							//$scope.newDoc();
							//scope.modelData={};
							if (model.$id==undefined){
							//	curmodels.create($scope.modelData).then(function(createdDoc) {
								curmodels.create(model).then(function(createdDoc) {

									console.log('done adding doc');
								//  $location.path('/');
								});
							} else {
								 curmodels.update($scope.modelData).then(function () {
									console.log('done saving');
									$location.path('/');
								});
							}
						}
				};
            }

            db.data = function(scope, callback) {
    				// emit car documents
    				/*  function map(doc) {
    				if(doc.type == 'car' && doc.value) {
    					emit(doc.value, null);
    				}
    				}

    				// filter results
    				function filter(err, response) {
    				if (err) return callback(err);

    				var matches = [];
    				response.rows.forEach(function(car) {
    					if (car.hp == horsePower) {
    					matches.push(car);
    					}
    				});
    				callback(null, matches);
    				}

    				// kick off the PouchDB query with the map & filter functions above
    				db.query({map: map}, {reduce: false}, filter)
    				*/

                function callback() { // return 0;
    				//	alert('call back');
					
					var tmpData=[];
					var lenData=scope.crmdata.length;
					
//					scope.crmdata.forEach(function(mapper) {

					for (var i=0;i<lenData;i++){
						
						var isFound=false;
						
						var mapper=scope.crmdata[i];
					

                        if ((mapper.type === undefined)) {
                           
                           console.log(mapper.id);
                        } else switch (mapper.type) { // commesse, offerte, matricola
                            case "matricola":
								isFound=true;
							break;
							 default:isFound=false;
						 }
						 
						if (isFound) tmpData.push(mapper);
						 
						//	delete scope.crmdata[i]; // va più veloce non ricalcola indici	
                       
                       
                        /*      if (doc[mapper.field].indexOf(mapper.value)) {
                                    
                                    if (result.hasOwnProperty(yearMonth)) {
                                        if (result[yearMonth].hasOwnProperty(mapper.category)) {
                                            result[yearMonth][mapper.category] += doc.debit + doc.credit;
                                        } else {
                                            result[yearMonth][mapper.category] = doc.debit + doc.credit;
                                        }
                                    } else {
                                        result[yearMonth] = {
                                            month: date.year() + '-' + date.month()
                                        };
                                        result[yearMonth][mapper.category] = doc.debit + doc.credit;
                                    }
                                }
                                break;
						
                            default:
                                throw new Error("CategoryMapper type not implemented yet!");
                       */
                    };
                    
                   // scope.crmdata=tmpData;
                    
                    scope.gridOptions.data=scope.crmdata;
					
                    		

                }

		
                return adapter(adapters[1], scope, 'crmdata', {}, callback);
            }

            return db;
        }
})();
