(function() {
    'use strict';



	angular.module('clienti')
		.controller('ClientiCtrl', ClientiCtrl);

		ClientiCtrl.$inject = [
			'$rootScope','$scope','$stateParams','crmService'
		];

		function ClientiCtrl ($rootScope,$scope,$stateParams,crmService) {
			console.log('ClientiCtrl');
		  
			var projects = null;
			var curmodels = {};
			var curmodel = {};
			
			$rootScope.pageChildCtrl=$scope;
			
			$scope.readonly=true;
			$scope.edit=false;
			
			$rootScope.curViewScope='';
			$rootScope.homeCtrl.setState('grid');
			
			$scope.barTitle='clienti';
		
		          $scope.gridOptions = {
						enableSorting: true,
						multiSelect: false,
						 showColumnMenu: true,   
						enableColumnResizing: true,
						columnDefs: [],
						data: [],
						"onRegisterApi": function(gridApi) {
							$scope.gridApi = gridApi;
						}
      
					};
			
			if ($stateParams.instanceID==undefined) $scope.instanceID=null;
			else $scope.instanceID = $stateParams.instanceID;
			

			
			var stateList=['grid','model','edit'];

			
			$scope.frm_edit=function(model){
				$rootScope.homeCtrl.setState('model');
				$scope.modelData =model;
			}
			
			/*	$scope.frm_remove(model){
					curmodels.remove(model);
				}
				*/
			
			crmService.getForm('form.clienti',$scope);
			

			
		
			crmService.data($scope).then(	function (projs) {
					console.log('crmService done binding');
					projs.cleanup();
					projects = projs;
					curmodels=projs;
					$scope.modelData =curmodel  ||  {};  //[{name:'etto',email:'email',comment:'mio commento'}]
					$scope.loaded = true; // hide loading spinner
					
			});
			
			
				}
	 
})();
