(function() {
    'use strict';



	angular.module('commesse')
		.controller('CommesseCtrl', CommesseCtrl);

		CommesseCtrl.$inject = [
			'$scope','$stateParams','crmService'
		];

		function CommesseCtrl ($scope,$stateParams,crmService) {
			console.log('CommesseCtrl');
		  
			var projects = null;
			var curmodels = {};
			var curmodel = {};
			
			if ($stateParams.instanceID==undefined) $scope.instanceID=null;
			else $scope.instanceID = $stateParams.instanceID;
			
			$scope.readonly=true;
			$scope.edit=false;
			
			var stateList=['grid','model','edit'];
			$scope.setState=function(state){
				if (state=='grid') $scope.edit=false;
				if (state=='model'){
					$scope.edit=true;
					$scope.readonly=true;
				}
				
				if (state=='edit') {
					$scope.readonly=false;
					$scope.edit=true;
				}
			}
			
			$scope.frm_edit=function(model){
				$scope.setState('model');
				$scope.modelData =model;
			}
			
			/*	$scope.frm_remove(model){
					curmodels.remove(model);
				}
				*/
			
			crmService.getForm('form.commesse',$scope);
			
		
			crmService.data($scope).then(	function (projs) {
					console.log('crmService done binding');
					projs.cleanup();
					projects = projs;
					curmodels=projs;
					$scope.modelData =curmodel  ||  {};  //[{name:'etto',email:'email',comment:'mio commento'}]
					$scope.loaded = true; // hide loading spinner
					
			});
			
			
			
	}
})();
