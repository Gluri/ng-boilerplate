(function () {
    'use strict';

    
    angular
        .module('app')
        .run(Run);


    Run.$inject = [
        '$rootScope',
        '$state',
        'adapters',
        'Auth'
    ];

    function Run($rootScope, $state, adapters, Auth) { 
        $rootScope.$on("$stateChangeStart", checkAuth);


        function checkAuth(event, toState, toParams, fromState, fromParams) {

            if (!Auth.authorize(toState.data.access)) {
                event.preventDefault();

                if (Auth.isLoggedIn()) {
                    $state.go('home');
                } else {
                    $state.go('login');
                }
            }
        }

          
    }

})();
