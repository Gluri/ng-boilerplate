(function() {
    'use strict';



	angular.module('offerte')
		.controller('OfferteCtrl', OfferteCtrl);

		OfferteCtrl.$inject = [
			'$scope',
			'crmService'
		];

		function OfferteCtrl ($scope,crmService) {
			console.log('OfferteCtrl');
		  
			var projects = null;
			var curmodels = {};
			var curmodel = {};
			
			$scope.edit=false;
			
			 
			$scope.frm_edit=function(model){
				$scope.edit=true;
				$scope.modelData =model;
			}
			
			/*	$scope.frm_remove(model){
					curmodels.remove(model);
				}
				*/
			/*	var myModal=btfModal({
					controller: 'contattiCtrl',
					controllerAs: 'modal',
					templateUrl: 'contatti/modal.tpl.html'
				});
		myModal.activate;*/

			
			crmService.getForm('form.offerte',$scope);
			
		
			crmService.data($scope).then(	function (projs) {
					console.log('crmService done binding');
					projs.cleanup();
					projects = projs;
					curmodels=projs;
					$scope.modelData =curmodel  ||  {};  //[{name:'etto',email:'email',comment:'mio commento'}]
					$scope.loaded = true; // hide loading spinner
					
			});
			
			
			$scope.itParses = true;
			$scope.itParsesForm = true;
			$scope.$watch('schemaJson',function(val,old){
				if (val && val !== old) {
					try {
						$scope.schema = JSON.parse($scope.schemaJson);
						$scope.itParses = true;
					} catch (e){
						$scope.itParses = false;
					}
				}
			});
	  
	  
			$scope.$watch('formJson',function(val,old){
			    if (val && val !== old) {
			      try {
			        $scope.form = JSON.parse($scope.formJson);
			        $scope.itParsesForm = true;
			      } catch (e){
			        $scope.itParsesForm = false;
			      }
			    }
			});
				
			$scope.$watch('selectedTest',function(val){
			    if (val) {
			    
			        $scope.schema =val.data.schema;
			        $scope.form   = val.data.form;
			        $scope.schemaJson = JSON.stringify($scope.schema,undefined,2);
			        $scope.formJson   = JSON.stringify($scope.form,undefined,2);
			        $scope.modelData = val.data.model ||  {}; //[{name:'etto',email:'email',comment:'mio commento'}]

			    }
			});
	  
	  
		    $scope.submitForm = function(form, model) {
				// First we broadcast an event so all fields validate themselves
				$scope.$broadcast('schemaFormValidate');
				// Then we check if the form is valid
				
			
				if (form.$valid) {
				//	alert('You did it!');
					$scope.edit=false;
					//$scope.newDoc();
					$scope.modelData={};
						if (1===1){ //if (model.$id==undefined){
					//	curmodels.create($scope.modelData).then(function(createdDoc) {
						curmodels.create(model).then(function(createdDoc) {

							console.log('done adding doc');
						//  $location.path('/');
						});
					} else {
						 curmodels.update($scope.modelData).then(function () {
							console.log('done saving');
							$location.path('/');
						});
					}
				}
			};
  

			//});


		//$scope.loaded = todos.bound(); // don't show spinner if already bound

		/*	todos.bind($sFcope).then(function () {
		        console.log('done binding');
				// console.log($scope.contacts);
				$scope.loaded = true; // hide loading spinner
			});*/
		  
				/*	var adapter = new Adapter('todos', 'http://127.0.0.1:5984', yngutils.ASC);
			
					adapter.bind($scope).then(function () {
						console.log('done binding');
						console.log($scope.todos);
						// $scope.todos[0] = adapter.at(0)
						// $scope.todos[0].$id = the unique id of the doc
						// $scope.todos[0].$priority = the priority/order of the doc
					});

					
					// create 
					adapter.create(doc).then(function(createdDoc) {
						console.log('done creating doc');
						// createdDoc.$id = the unique id of the new doc
					});
		*/	
			
			
			
			
	}
})();
