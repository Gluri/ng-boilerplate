(function() {
	'use strict';

    angular.module('adapters')

    .service('adapters', function() {
        return [
            {
            name: 'dataForms',
            adapter:'Pouchyng',
            dbname:'crmforms',
            url: 'https://ilbimbocresce.couchappy.com', // or e.g. http://127.0.0.1:5984
            files: [
            'assets/adapters/pouchdb.min.js',
            //'http://cdn.jsdelivr.net/pouchdb/3.0.5/pouchdb.js',
            'assets/adapters/pouchyng.js'] // or e.g. ../../dist/adapters/pouchyng.min.js
           
            },
            {
            name: 'data',
            adapter:'Pouchyng',
            dbname:'crmdata',
            url: 'https://ilbimbocresce.couchappy.com', // or e.g. http://127.0.0.1:5984
            files: [
            'assets/adapters/pouchdb.min.js',
            'assets/adapters/pouchyng.js']
            
            }		  
            // Add new adapter here
        ];
    });
})(); 
