(function() {
    'use strict';

    angular
        .module('model.user', [ 
            'sofa'
        ])

})();