(function() {
    'use strict';

    angular
        .module('sofa', [

        ]);

})();