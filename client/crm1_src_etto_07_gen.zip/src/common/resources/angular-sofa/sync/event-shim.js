// Prevent undefined module error when including event.js

/* jshint ignore:start */

/* istanbul ignore next */
if (!module) {
  var module = {};
}

/* jshint ignore:end */